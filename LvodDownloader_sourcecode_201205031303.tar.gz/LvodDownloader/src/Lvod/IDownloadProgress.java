/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lvod;

/**
 *
 * @author wcss
 */
public interface IDownloadProgress 
{
   void onReportProgress(DownLoader sender, double currentlength,double totallength);   
   void onReportError(DownLoader sender,String code,String errormsg);
   void onReportFinish(DownLoader sender);
   void onReportStatus(DownLoader sender);
}
