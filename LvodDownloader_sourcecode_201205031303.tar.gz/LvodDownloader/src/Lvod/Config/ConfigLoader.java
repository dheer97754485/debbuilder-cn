/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lvod.Config;

import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author wcss
 */
public class ConfigLoader 
{
   public String qvodSourceFile = "/opt/lvodDownloader/sq_hide_compress.exe";
   public double qvodSourceLength = 544;
   public int downloadTimeout = 120;
   public String downloadRunScript = "wine (File)";
   public String playRunScript = "smplayer (File)";
   public String downloadDir = "~/lvodDownload";
   public String playListName = "lvodplaylist.dat";
   
   public static String systemConfigPath = "/etc/lvoddownloader.cfg";
   public static ConfigLoader config = new ConfigLoader();
   
   /**
    * load config
    * @throws Exception 
    */
   public void loadConfig() throws Exception
   {
       if (new File(ConfigLoader.systemConfigPath).exists())
       {
           String[] configs = jAppHelper.jDataRWHelper.readAllLines(ConfigLoader.systemConfigPath);
           for(String str:configs)
           {
               if (str.contains("qvodSourceFile="))
               {
                   this.qvodSourceFile = str.trim().replace("qvodSourceFile=", "");
               }
               else if (str.contains("qvodSourceLength="))
               {
                   this.qvodSourceLength = Double.parseDouble(str.trim().replace("qvodSourceLength=", ""));
               }
               else if (str.contains("downloadTimeout="))
               {
                   this.downloadTimeout = Integer.parseInt(str.trim().replace("downloadTimeout=", ""));
               }
               else if (str.contains("downloadRunScript="))
               {
                   this.downloadRunScript = str.trim().replace("downloadRunScript=", "");
               }
               else if (str.contains("playRunScript="))
               {
                   this.playRunScript = str.trim().replace("playRunScript=", "");
               }
               else if  (str.contains("downloadDir="))
               {
                   this.downloadDir = str.trim().replace("downloadDir=", "");
               }
               else if  (str.contains("playListName="))
               {
                   this.playListName = str.trim().replace("playListName=", "");
               }
           }
       }
   }
   
   /**
    * save config
    */
   public void saveConfig(String savepath) throws Exception
   {
      ArrayList<String> configss = new ArrayList<String>();
      configss.add("qvodSourceFile=" + this.qvodSourceFile);
      configss.add("qvodSourceLength=" + this.qvodSourceLength);
      configss.add("downloadTimeout=" + this.downloadTimeout);
      configss.add("downloadRunScript=" + this.downloadRunScript);
      configss.add("playRunScript=" + this.playRunScript);
      configss.add("downloadDir=" + this.downloadDir);
      configss.add("playListName=" + this.playListName);
      jAppHelper.jDataRWHelper.writeAllLines(savepath, jAppHelper.jDataRWHelper.convertTo(configss.toArray()));
   }
   
}
