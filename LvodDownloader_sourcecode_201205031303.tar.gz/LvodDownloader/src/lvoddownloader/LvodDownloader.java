/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lvoddownloader;

import Lvod.DownLoader;
import Lvod.IDownloadProgress;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wcss
 */
public class LvodDownloader implements IDownloadProgress{

    /**
     * @param args the command line arguments
     */
    public static void aaaaa(String[] args) 
    {
        // TODO code application logic here

        new LvodDownloader().startdownload();
    }
    
    public void startdownload()
    {
        DownLoader d = new DownLoader();
        try {
            d.initDownloader("qvod://235214032|5AAD0EA01AC5EABAA9DDA2AC391B04A54EC77293|夏家三千金_《夏家三千金》第1集.mp4|",this);
            d.start();
        } catch (Exception ex) {
            Logger.getLogger(LvodDownloader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void onReportProgress(DownLoader sender, double currentlength, double totallength) 
    {
        System.out.println("Current:" + currentlength);
    }

    @Override
    public void onReportError(DownLoader sender, String code, String errormsg) {
        System.out.println("Error:" + errormsg);
    }

    @Override
    public void onReportFinish(DownLoader sender) {
        System.out.println("Finish");
    }

    @Override
    public void onReportStatus(DownLoader sender) {
        
    }
}
