/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lvoddownloader;

import Lvod.*;
import Lvod.Config.ConfigLoader;
import Lvod.PlayList.PlayListLoader;
import LvodServer.JReportQvodUrl;
import LvodServer.SingleHTTPServer;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.logging.*;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author wcss
 */
public class QvodDownLoad extends javax.swing.JFrame implements IDownloadProgress, Runnable, JReportQvodUrl {

    private DownLoader qvodDownLoad = new DownLoader();
    private HashMap<String, DownLoader> downloadList = new HashMap<String, DownLoader>();
    private int currentViewTaskIndex = 0;
    private String currentViewTaskUrl = "";
    private Boolean isRunTask = false;
    private Thread workThread = null;
    private int currentTaskIndex = 0;
    private HashMap<String, SpeedEntry> downloadProgresses = new HashMap<String, SpeedEntry>();
    private long runTimes = 0;
    private TrayIcon trayIcon = null; // 托盘图标  
    private SystemTray tray = null; // 本操作系统托盘的实例  

    /**
     * Creates new form QvodDownLoad
     */
    public QvodDownLoad() {
        //判断是否支持托盘  
        //if (SystemTray.isSupported()) {  
        this.runTray();
        //}  
        initComponents();
        this.btnPasteAdd.setVisible(false);
        try {
            SingleHTTPServer.startListen(this);
            this.setTitle(this.getTitle() + " 端口：" + SingleHTTPServer.listenPort);
            ConfigLoader.config.saveConfig(jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/lvod.config");
            ConfigLoader.config.loadConfig();
            setDownloadDir();
            PlayListLoader.playlist.loadPlayList();
            uploadDownLoadLists();
            Thread tt = new Thread(this);
            tt.setDaemon(true);
            tt.start();
        } catch (Exception ex) {
            Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * 检查同时下载是否为3
     */
    private Boolean checkDonwloaderMaxCount() {
        Boolean result = false;
        int runningcount = 0;
        Object[] values = downloadList.values().toArray();
        for (Object obj : values) {
            DownLoader dll = (DownLoader) obj;
            if (dll.isRunning()) {
                runningcount++;
            }
        }
        if (runningcount < 3) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    /**
     * 设置下载目录
     */
    private void setDownloadDir() {
        File dir = new File(ConfigLoader.config.downloadDir);
        if (dir.exists()) {
            //目录存在，不与处理
        } else {
            ConfigLoader.config.downloadDir = jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/视频/QvodMovies";
            File dircreate = new File(ConfigLoader.config.downloadDir);
            dircreate.mkdirs();
        }
    }

    /**
     * 启动托盘 ImageIcon icon = new ImageIcon(new
     * File(ConfigLoader.config.qvodSourceFile).getParent() + "/trayimg.png");
     */
    private void runTray() {
        if (SystemTray.isSupported()) {
            try {
                //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                System.out.println(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
            }
//            tray = SystemTray.getSystemTray();
//            ImageIcon icon = new ImageIcon(new File(ConfigLoader.config.qvodSourceFile).getParent() + "/trayimg.png");
//
//
//            PopupMenu pop = new PopupMenu(); // 构造一个右键弹出式菜单  
//            MenuItem show = new MenuItem("显示窗口");
//            MenuItem exit = new MenuItem("退出演示");
//            trayIcon = new TrayIcon(icon.getImage(), "托盘技术演示", pop);
//
//            MouseListener mouseListener = new MouseListener() {
//
//                public void mouseClicked(MouseEvent e) {
//                    System.out.println("Tray Icon - Mouse clicked!");
//                }
//
//                public void mouseEntered(MouseEvent e) {
//                    System.out.println("Tray Icon - Mouse entered!");
//                }
//
//                public void mouseExited(MouseEvent e) {
//                    System.out.println("Tray Icon - Mouse exited!");
//                }
//
//                public void mousePressed(MouseEvent e) {
//                    System.out.println("Tray Icon - Mouse pressed!");
//                }
//
//                public void mouseReleased(MouseEvent e) {
//                    System.out.println("Tray Icon - Mouse released!");
//                }
//            };
//
//            ActionListener actionListener = new ActionListener() {
//
//                public void actionPerformed(ActionEvent e) {
//                    trayIcon.displayMessage("Action Event",
//                            "An Action Event Has Been Performed!",
//                            TrayIcon.MessageType.INFO);
//                }
//            };
//
//            trayIcon.setImageAutoSize(true);
//            trayIcon.addActionListener(actionListener);
//            trayIcon.addMouseListener(mouseListener);
//
//            try {
//                if (tray != null) {
//                    //trayIcon.displayMessage("欢迎使用", "qvod下载器", TrayIcon.MessageType.ERROR);
//                    //trayIcon.setImageAutoSize(true);
//                    //trayIcon.setActionCommand("trayshow");
//                    tray.add(trayIcon);
//                }
//            } catch (Exception ex) {
//                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
//            }
//            pop.add(show);
//            pop.add(exit);
        }
    }

    /**
     *
     * @throws Exception
     */
    public void uploadDownLoadList(Boolean initDownLoad) throws Exception {
        ArrayList al = new ArrayList();
        DownLoader downItem = null;
        if (initDownLoad) {
            downloadList.clear();
        }
        for (String str : PlayListLoader.playlist.playList) {
            try {
                if (downloadList.containsKey(str)) {
                    downItem = downloadList.get(str);
                    if (!new File(downItem.qvodShellFile).exists()) {
                        downItem.initDownloader(str, this);
                    }
                } else {
                    downItem = new DownLoader();
                    downItem.initDownloader(str, this);
                    if (downItem.checkQvodUrl(str)) {
                        downloadList.put(str, downItem);
                    }
                }
                String statetext = "";
                if (downItem.isRunning()) {
                    if (downloadList.get(str).getCurrentLength() <= 0) {
                        statetext = "[搜索地址]";
                    } else {
                        statetext = "[正在下载]";
                    }
                } else {
                    if (downloadList.get(str).getCurrentLength() >= downloadList.get(str).movieFileLength) {
                        statetext = "[下载完成]";
                    } else {
                        statetext = "[未完成]";
                    }
                }

                al.add(statetext + downItem.getMovieStr(str));
            } catch (Exception ex) {
                System.out.println("地址:" + str + "转换出错！信息：" + ex.toString());
            }
        }
        ArrayList showlistss = new ArrayList();
        for (int f = al.size() - 1; f >= 0; f--) {
            showlistss.add(al.get(f));
        }
        lstPlayList.setListData(showlistss.toArray());
        if (al.size() > 0) {
            this.btnAllStart.setEnabled(true);
        } else {
            this.btnAllStart.setEnabled(false);
        }
    }

    /**
     *
     * @throws Exception
     */
    public void uploadDownLoadLists() throws Exception {
        uploadDownLoadList(true);
    }

    public void startdownload() {
        try {
            //DownLoader.qvodTimeout = 120;
            qvodDownLoad.initDownloader("qvod://235214032|5AAD0EA01AC5EABAA9DDA2AC391B04A54EC77293|夏家三千金_《夏家三千金》第1集.mp4|", this);
            qvodDownLoad.start();
        } catch (Exception ex) {
            Logger.getLogger(LvodDownloader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblQvod = new javax.swing.JLabel();
        textQvodUrl = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnConfig = new javax.swing.JButton();
        btnPasteAdd = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstPlayList = new javax.swing.JList();
        btnDelMovie = new javax.swing.JButton();
        btnStartDownLoad = new javax.swing.JButton();
        btnStopDownLoad = new javax.swing.JButton();
        btnPlayMovie = new javax.swing.JButton();
        btnMoveUp = new javax.swing.JButton();
        btnMoveDown = new javax.swing.JButton();
        btnAllStart = new javax.swing.JButton();
        btnAllStop = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lblMovieName = new javax.swing.JLabel();
        textMovieName = new javax.swing.JTextField();
        progressBar = new javax.swing.JProgressBar();
        lblDownLoadState = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textErrorReport = new javax.swing.JTextPane();
        lblProgressInfo = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("QvodDownLoader V1.2 QQ707519239 邮箱：wcss2020@gmail.com");
        setPreferredSize(new java.awt.Dimension(709, 690));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("工具栏"));

        lblQvod.setText("Qvod地址:");

        textQvodUrl.setText("qvod://");

        btnAdd.setText("从输入框添加");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnConfig.setText("配置");
        btnConfig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfigActionPerformed(evt);
            }
        });

        btnPasteAdd.setText("从剪切板添加");
        btnPasteAdd.setEnabled(false);
        btnPasteAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPasteAddActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQvod)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textQvodUrl, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAdd)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnConfig)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnPasteAdd)
                .addGap(162, 162, 162))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblQvod)
                    .addComponent(textQvodUrl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdd)
                    .addComponent(btnConfig)
                    .addComponent(btnPasteAdd))
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("下载列表"));

        lstPlayList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstPlayListMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(lstPlayList);

        btnDelMovie.setText("删除");
        btnDelMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelMovieActionPerformed(evt);
            }
        });

        btnStartDownLoad.setText("开始下载");
        btnStartDownLoad.setEnabled(false);
        btnStartDownLoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartDownLoadActionPerformed(evt);
            }
        });

        btnStopDownLoad.setText("停止下载");
        btnStopDownLoad.setEnabled(false);
        btnStopDownLoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStopDownLoadActionPerformed(evt);
            }
        });

        btnPlayMovie.setText("播放影片");
        btnPlayMovie.setEnabled(false);
        btnPlayMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlayMovieActionPerformed(evt);
            }
        });

        btnMoveUp.setText("向上移动");
        btnMoveUp.setEnabled(false);
        btnMoveUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoveUpActionPerformed(evt);
            }
        });

        btnMoveDown.setText("向下移动");
        btnMoveDown.setEnabled(false);
        btnMoveDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoveDownActionPerformed(evt);
            }
        });

        btnAllStart.setText("全部下载");
        btnAllStart.setEnabled(false);
        btnAllStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAllStartActionPerformed(evt);
            }
        });

        btnAllStop.setText("全部停止");
        btnAllStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAllStopActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 565, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelMovie, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnStartDownLoad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnStopDownLoad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPlayMovie, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnMoveUp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnMoveDown, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAllStart, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAllStop, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnDelMovie)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnStartDownLoad)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnStopDownLoad)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPlayMovie)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnMoveUp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnMoveDown)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAllStop)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAllStart)))
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("下载进度"));

        lblMovieName.setText("影片名称：");

        textMovieName.setEditable(false);
        textMovieName.setText("movie.rmvb");

        lblDownLoadState.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDownLoadState.setText("空");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblDownLoadState, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(lblMovieName)
                        .addGap(1, 1, 1)
                        .addComponent(textMovieName))
                    .addComponent(progressBar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMovieName)
                    .addComponent(textMovieName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDownLoadState)
                .addContainerGap())
        );

        jScrollPane2.setViewportView(textErrorReport);

        lblProgressInfo.setFont(new java.awt.Font("DejaVu Sans YuanTi", 0, 24)); // NOI18N
        lblProgressInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblProgressInfo.setText("0");

        jEditorPane1.setFont(new java.awt.Font("DejaVu Sans YuanTi", 0, 14)); // NOI18N
        jEditorPane1.setText("下载器 开发组：  凝¤决(负责chromium插件，Firefox插件开发)              五彩书生(负责Qvod下载器开发)\n本程序是出于学习交流为目的制作开发的，主要是为了Linux下各位朋友使用方面，绝无任何商业用途，如有侵权请告知！谢谢!");
        jEditorPane1.setMinimumSize(new java.awt.Dimension(6, 80));
        jEditorPane1.setPreferredSize(new java.awt.Dimension(98, 80));
        jScrollPane3.setViewportView(jEditorPane1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblProgressInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblProgressInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        // TODO add your handling code here:
        if (qvodDownLoad.checkQvodUrl(this.textQvodUrl.getText().trim())) {
            if (PlayListLoader.playlist.playList.contains(this.textQvodUrl.getText().trim())) {
                this.textQvodUrl.setText("qvod://");
                javax.swing.JOptionPane.showMessageDialog(null, "请不要重复添加！");
            } else {

                PlayListLoader.playlist.playList.add(this.textQvodUrl.getText().trim());
                try {
                    PlayListLoader.playlist.savePlayList(jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/" + ConfigLoader.config.playListName);
                    this.uploadDownLoadList(false);
                    this.textQvodUrl.setText("qvod://");
                    javax.swing.JOptionPane.showMessageDialog(null, "Qvod地址添加完成!");
                } catch (Exception ex) {
                    Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } else {
            javax.swing.JOptionPane.showMessageDialog(null, "无效的Qvod地址！格式：qvod://235214032|5AAD0EA01AC5EABAA9DDA2AC391B04A54EC77293|夏家三千金_《夏家三千金》第1集.mp4|");
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnConfigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfigActionPerformed
        // TODO add your handling code here:
        new ConfigEditor().setVisible(true);
    }//GEN-LAST:event_btnConfigActionPerformed

    private void btnDelMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelMovieActionPerformed
        // TODO add your handling code here:
        if (this.currentViewTaskUrl == "") {
            javax.swing.JOptionPane.showMessageDialog(null, "请先选择一个下载项，然后点击删除！");
        } else {
            if (this.downloadList.get(this.currentViewTaskUrl).isRunning()) {
                javax.swing.JOptionPane.showMessageDialog(null, "不能删除正在运行中的下载项！");
            } else {
                PlayListLoader.playlist.playList.remove(this.currentViewTaskUrl);
                try {
                    PlayListLoader.playlist.savePlayList(jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/" + ConfigLoader.config.playListName);
                    jAppHelper.jCmdRunHelper.runSysCmd("rm -rf " + this.downloadList.get(this.currentViewTaskUrl).qvodWorkDir);
                    this.downloadList.remove(this.currentViewTaskUrl);
                    uploadDownLoadList(false);
                    this.currentViewTaskIndex = -1;
                    this.currentViewTaskUrl = "";
                } catch (Exception ex) {
                    Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_btnDelMovieActionPerformed

    private void btnStartDownLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartDownLoadActionPerformed
        // TODO add your handling code here:
        if (currentViewTaskUrl != "") {
            try {
                if (this.isRunTask) {
                    javax.swing.JOptionPane.showMessageDialog(null, "‘全部下载’模式下不能进行此操作!");
                } else {
                    if (checkDonwloaderMaxCount()) {
                        downloadList.get(currentViewTaskUrl).start();
                        this.uploadDownLoadList(false);
                        this.showTaskProgress(currentViewTaskUrl);
                        btnStartDownLoad.setEnabled(false);
                        btnStopDownLoad.setEnabled(true);
                        btnAllStart.setEnabled(false);
                    } else {
                        javax.swing.JOptionPane.showMessageDialog(null, "对不起，只能同时下载3个任务！");
                    }
                }
            } catch (Exception ex) {
                this.textErrorReport.setText(ex.toString());
            }
        }
    }//GEN-LAST:event_btnStartDownLoadActionPerformed

    private void btnStopDownLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStopDownLoadActionPerformed
        // TODO add your handling code here:
        if (currentViewTaskUrl != "") {
            try {
                if (downloadList.get(currentViewTaskUrl).getCurrentLength() < downloadList.get(currentViewTaskUrl).movieFileLength) {
                    btnStartDownLoad.setEnabled(true);
                } else {
                    btnStartDownLoad.setEnabled(false);
                }
                btnStopDownLoad.setEnabled(false);
                btnAllStart.setEnabled(true);
                downloadList.get(currentViewTaskUrl).stop();
                downloadList.get(currentViewTaskUrl).dispose();
                this.uploadDownLoadList(false);
                if (this.downloadProgresses.containsKey(currentViewTaskUrl)) {
                    this.downloadProgresses.remove(currentViewTaskUrl);
                }
                this.showTaskProgress(currentViewTaskUrl);
            } catch (Exception ex) {
                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnStopDownLoadActionPerformed

    private void btnPlayMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlayMovieActionPerformed
        // TODO add your handling code here:
        if (currentViewTaskUrl != "") {
            File destpath = new File(ConfigLoader.config.downloadDir + "/" + this.downloadList.get(currentViewTaskUrl).getDownLoadMovieStr(this.downloadList.get(currentViewTaskUrl).qvodUrl));
            String play = "";
            if (destpath.exists()) {
                play = ConfigLoader.config.playRunScript.replace("(File)", destpath.getAbsolutePath());
            } else {
                if (new File(this.downloadList.get(currentViewTaskUrl).movieFile).exists()) {
                    play = ConfigLoader.config.playRunScript.replace("(File)", this.downloadList.get(currentViewTaskUrl).movieFile);
                } else {
                    play = ConfigLoader.config.playRunScript.replace("(File)", this.downloadList.get(currentViewTaskUrl).qvodWorkDir + "/" + this.downloadList.get(currentViewTaskUrl).getMovieFileName());
                }
            }

            try {
                ArrayList contents = new ArrayList();
                contents.add(play);
                jAppHelper.jDataRWHelper.writeAllLines(jAppHelper.jCmdRunHelper.getCmdRunScriptBufferDir() + "/playmovie.sh", jAppHelper.jDataRWHelper.convertTo(contents.toArray()));
                jAppHelper.jCmdRunHelper.runSysCmd("chmod +x " + jAppHelper.jCmdRunHelper.getCmdRunScriptBufferDir() + "/playmovie.sh");
                jAppHelper.jCmdRunHelper.runSysCmd(jAppHelper.jCmdRunHelper.getCmdRunScriptBufferDir() + "/playmovie.sh", false);
            } catch (Exception ex) {
                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnPlayMovieActionPerformed

    private void btnMoveUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoveUpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnMoveUpActionPerformed

    private void btnMoveDownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoveDownActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnMoveDownActionPerformed

    private void lstPlayListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstPlayListMouseClicked
        // TODO add your handling code here:
        currentViewTaskIndex = (PlayListLoader.playlist.playList.size() - 1) - lstPlayList.getSelectedIndex();
        currentViewTaskUrl = PlayListLoader.playlist.playList.get(currentViewTaskIndex);
        try {
            if (this.downloadList.get(currentViewTaskUrl).getCurrentLength() >= this.downloadList.get(currentViewTaskUrl).movieFileLength) {
                this.btnPlayMovie.setEnabled(true);
            } else {
                this.btnPlayMovie.setEnabled(false);
            }
            if (this.downloadList.get(currentViewTaskUrl).getCurrentLength() < this.downloadList.get(currentViewTaskUrl).movieFileLength) {
                if (this.downloadList.get(currentViewTaskUrl).isRunning()) {
                    this.btnStartDownLoad.setEnabled(false);
                    this.btnStopDownLoad.setEnabled(true);

                } else {
                    this.btnStartDownLoad.setEnabled(true);
                    this.btnStopDownLoad.setEnabled(false);
                }
            } else {
                this.btnStartDownLoad.setEnabled(false);
                this.btnStopDownLoad.setEnabled(false);
            }
            if (this.isRunTask) {
                this.btnStartDownLoad.setEnabled(false);
                this.btnStopDownLoad.setEnabled(false);
            } else {
                //this.btnStopDownLoad.setEnabled(true);
            }
            showTaskProgress(currentViewTaskUrl);

        } catch (Exception ex) {
            Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_lstPlayListMouseClicked

    /**
     *
     * @param qvodurl
     */
    private void showTaskProgress(String qvodurl) {
        DownLoader dl = this.downloadList.get(qvodurl);
        if (dl != null) {
            try {
                this.textMovieName.setText(dl.getDownLoadMovieStr(dl.qvodUrl));
                this.progressBar.setMaximum((int) dl.movieFileLength);
                this.progressBar.setValue((int) dl.getCurrentLength());
                String state = dl.isRunning() ? "运行中" : "空闲中";
                String current = String.valueOf((int) (dl.getCurrentLength() / 1024));
                String maxium = String.valueOf((int) (dl.movieFileLength / 1024));
                //System.out.println(((double)this.progressBar.getValue() / (double)this.progressBar.getMaximum()));
                int percent = (int) (((double) this.progressBar.getValue() / (double) this.progressBar.getMaximum()) * 100);
                if (percent >= 7) {
                    btnPlayMovie.setEnabled(true);
                }
                long speedvalue = 0;
                long runsecond = 0;
                if (this.downloadProgresses.containsKey(qvodurl)) {
                    speedvalue = ((SpeedEntry) this.downloadProgresses.get(qvodurl)).speed;
                    runsecond = runTimes - ((SpeedEntry) this.downloadProgresses.get(qvodurl)).startTime;
                }
                if (speedvalue > 100000) {
                    speedvalue = 100;
                }
                this.lblDownLoadState.setText("已下载" + current + "M 总共" + maxium + "M 完成度:" + percent + "% 速度：" + speedvalue + "K/S 当前状态：" + state + "," + dl.qvodStateStr);
            } catch (Exception ex) {
                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void btnAllStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAllStartActionPerformed
        // TODO add your handling code here:
        currentTaskIndex = 0;
        this.isRunTask = true;
        try {
            this.downloadList.get(PlayListLoader.playlist.playList.get(this.currentTaskIndex)).start();
            this.uploadDownLoadList(false);
            btnAllStart.setEnabled(false);
            btnAllStop.setEnabled(true);
            btnStopDownLoad.setEnabled(false);
            btnStartDownLoad.setEnabled(false);
            //this.lstPlayList.setSelectedIndex(0);
        } catch (Exception ex) {
            this.textErrorReport.setText(ex.toString());
        }
    }//GEN-LAST:event_btnAllStartActionPerformed

    private void btnAllStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAllStopActionPerformed
        // TODO add your handling code here:
        currentTaskIndex = 0;
        try {
            if (downloadList.get(currentViewTaskUrl).getCurrentLength() < downloadList.get(currentViewTaskUrl).movieFileLength) {
                btnStartDownLoad.setEnabled(true);
            } else {
                btnStartDownLoad.setEnabled(false);
            }
        } catch (Exception ex) {
            Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.isRunTask = false;
        for (String str : PlayListLoader.playlist.playList) {
            try {
                this.downloadList.get(str).stop();
                this.downloadList.get(str).dispose();
            } catch (Exception ex) {
                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        try {
            this.uploadDownLoadList(false);
            this.downloadProgresses.clear();
        } catch (Exception ex) {
            Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
        }
        btnAllStart.setEnabled(true);
        //btnAllStop.setEnabled(false);
        btnStopDownLoad.setEnabled(false);
        if (this.currentViewTaskUrl != null) {
            this.showTaskProgress(currentViewTaskUrl);
        }

    }//GEN-LAST:event_btnAllStopActionPerformed

    private void btnPasteAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPasteAddActionPerformed
        // TODO add your handling code here:
        this.textQvodUrl.setText(Tool.getSysClipboardText());
        this.btnAddActionPerformed(evt);
    }//GEN-LAST:event_btnPasteAddActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        btnAllStopActionPerformed(null);
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QvodDownLoad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QvodDownLoad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QvodDownLoad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QvodDownLoad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    new QvodDownLoad().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnAllStart;
    private javax.swing.JButton btnAllStop;
    private javax.swing.JButton btnConfig;
    private javax.swing.JButton btnDelMovie;
    private javax.swing.JButton btnMoveDown;
    private javax.swing.JButton btnMoveUp;
    private javax.swing.JButton btnPasteAdd;
    private javax.swing.JButton btnPlayMovie;
    private javax.swing.JButton btnStartDownLoad;
    private javax.swing.JButton btnStopDownLoad;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblDownLoadState;
    private javax.swing.JLabel lblMovieName;
    private javax.swing.JLabel lblProgressInfo;
    private javax.swing.JLabel lblQvod;
    private javax.swing.JList lstPlayList;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextPane textErrorReport;
    private javax.swing.JTextField textMovieName;
    private javax.swing.JTextField textQvodUrl;
    // End of variables declaration//GEN-END:variables
    private Date nowtime = new Date();

    private void reportDownLoadProgress(String did, double current, double total) {
        if (this.downloadProgresses.containsKey(did)) {
            SpeedEntry se = (SpeedEntry) this.downloadProgresses.get(did);
            se.length = total;
            if (se.startTime == 0 && current > se.current) {
                se.startTime = runTimes;
            }
            long ntime = runTimes - se.startTime;
            se.speed = (int) ((current - se.current) / ntime);
        } else {
            SpeedEntry see = new SpeedEntry(current, total);
            see.speed = 0;
            see.startTime = 0;
            this.downloadProgresses.put(did, see);
        }
    }

    @Override
    public void onReportProgress(DownLoader sender, double currentlength, double totallength) {
        reportDownLoadProgress(sender.qvodUrl, currentlength, totallength);
        if (this.currentViewTaskUrl != "") {
            //this.lblProgressInfo.setText((this.currentTaskIndex + 1) + "/" + PlayListLoader.playlist.playList.size());
            this.showTaskProgress(this.currentViewTaskUrl);
        }
    }

    @Override
    public void onReportError(DownLoader sender, String code, String errormsg) {
        this.textErrorReport.setText(errormsg);
        this.btnAllStopActionPerformed(null);
        try {
            //this.lblProgressInfo.setText((this.currentTaskIndex + 1) + "/" + PlayListLoader.playlist.playList.size());
            this.uploadDownLoadList(false);
        } catch (Exception ex) {
            Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void onReportFinish(DownLoader sender) {
        File destpath = new File(ConfigLoader.config.downloadDir + "/" + sender.getDownLoadMovieStr(sender.qvodUrl));
        //this.lblProgressInfo.setText((this.currentTaskIndex + 1) + "/" + PlayListLoader.playlist.playList.size());
        if (destpath.exists()) {
            //不需要复制
        } else {
            try {
                jAppHelper.jCmdRunHelper.runSysCmd("cp " + sender.movieFile + " " + destpath, false);
            } catch (Exception ex) {
                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (this.currentViewTaskUrl != "") {
            //this.lblProgressInfo.setText((this.currentTaskIndex + 1) + "/" + PlayListLoader.playlist.playList.size());
            this.showTaskProgress(this.currentViewTaskUrl);
        }

        try {
            this.uploadDownLoadList(false);
        } catch (Exception ex) {
            Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (this.isRunTask) {
            this.currentTaskIndex++;
            //this.lstPlayList.setSelectedIndex(this.currentTaskIndex);
            if (this.currentTaskIndex < PlayListLoader.playlist.playList.size()) {
                try {
                    this.downloadList.get(PlayListLoader.playlist.playList.get(this.currentTaskIndex)).start();
                    this.uploadDownLoadList(false);
                    this.btnAllStart.setEnabled(false);
                } catch (Exception ex) {
                    this.textErrorReport.setText(ex.toString());
                }
            }
            //this.lblProgressInfo.setText((this.currentTaskIndex + 1) + "/" + PlayListLoader.playlist.playList.size());
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000);
                runTimes++;

                long hour = (runTimes / 60) / 60;
                long minute = (runTimes - (hour * 60) * 60) / 60;
                long second = runTimes - ((hour * 60) * 60) - (minute * 60);
                this.lblProgressInfo.setText("已运行" + hour + "小时" + minute + "分钟" + second + "秒");
            } catch (InterruptedException ex) {
                Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /*
     * 自动添加地址
     */
    protected void addQvodUrls(String urlcontent) {
        // TODO add your handling code here:
        if (qvodDownLoad.checkQvodUrl(urlcontent)) {
            if (PlayListLoader.playlist.playList.contains(urlcontent)) {
                this.textQvodUrl.setText("qvod://");
                SingleHTTPServer.resultText = "have";
            } else {

                PlayListLoader.playlist.playList.add(urlcontent);
                try {
                    PlayListLoader.playlist.savePlayList(jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/" + ConfigLoader.config.playListName);
                    this.uploadDownLoadList(false);
                    this.textQvodUrl.setText("qvod://");
                    SingleHTTPServer.resultText = "ok";
                } catch (Exception ex) {
                    Logger.getLogger(QvodDownLoad.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } else {
            SingleHTTPServer.resultText = "error";
        }
    }

    @Override
    public void reportQvodUrl(Object sender, String url) {
        //this.textQvodUrl.setText(url);
        addQvodUrls(url);
    }

    @Override
    public void onReportStatus(DownLoader sender) {
        if (this.currentViewTaskUrl != null) {
            this.showTaskProgress(currentViewTaskUrl);
        }
    }
}
