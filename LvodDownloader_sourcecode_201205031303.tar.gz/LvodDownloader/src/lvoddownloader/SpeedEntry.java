/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lvoddownloader;

/**
 *
 * @author wcss
 */
public class SpeedEntry 
{
   public SpeedEntry(double v,double l)
   {
       this.current = v;
       this.length = l;
   }
   public double length = 0;
   public double current = 0;
   public int speed = 0;
   public long startTime = 0;
}
