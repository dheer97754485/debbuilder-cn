/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LvodServer;

/**
 *
 * @author wcss
 */
public interface JReportQvodUrl
{
    void reportQvodUrl(Object sender,String url);    
}
