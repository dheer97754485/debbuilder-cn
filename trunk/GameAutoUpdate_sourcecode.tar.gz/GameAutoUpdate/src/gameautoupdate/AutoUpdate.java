/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gameautoupdate;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wcss
 */
public class AutoUpdate extends javax.swing.JFrame implements Runnable
{
    public static HttpGet downloadTools = new HttpGet();
    public static String updateCache = "";
    public static String updateConfigCache = "";
    public static String updateFilesCache = "";
    public static ArrayList<String> updateRemoteList = new ArrayList<String>();
    public static ArrayList<String> updateLocalList = new ArrayList<String>();
    public ArrayList<String> updatelogs = new ArrayList<String>();
    public static WaitUpdate waitForm = null;
    public static String languageName = "";
    public static ArrayList<String> languageStrs = new ArrayList<String>();
    public static int maxUpdateVersion = 0;
    public static int needDownloadFileCount = 0;
    private int currentDownloadFileIndex = 0;
    /**
     * Creates new form AutoUpdate
     */
    public AutoUpdate() throws Exception 
    {
        initComponents();
        loadLanguage();
        lblUpdateState.setVisible(false);
        
        //载入配置文件
        File f = new File(UpdateConfig.configPath);
        if (f.exists()) {
            try {
                //UpdateConfig.config.loadConfig();
                //this.downloadTools.form = this;
                this.lblHomePage.setText(UpdateConfig.config.homePage);
                this.lblManagerInfo.setText(UpdateConfig.config.managerInfo);
                if (!AutoUpdate.languageName.equals("zh-cn"))
                {
                    this.waitForm.setTitle("<" + UpdateConfig.config.softName + "> Auto Update");
                    this.setTitle("<" + UpdateConfig.config.softName + "> Auto Update！");
  
                }else
                {
                    this.waitForm.setTitle("<" + UpdateConfig.config.softName + ">自动更新程序");
                    this.setTitle("检查<" + UpdateConfig.config.softName + ">程序的更新！");
                }
                showUpdateState("read config...", 5);
                AutoUpdate.updateCache = jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/.gameautoupdatecache";
                AutoUpdate.updateConfigCache = jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/.gameautoupdatecache/lists";
                AutoUpdate.updateFilesCache = jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/.gameautoupdatecache/files";

                File dir1 = new File(AutoUpdate.updateCache);
                if (dir1.exists()) {
                    dir1.delete();
                }
                dir1.mkdirs();
                File dir2 = new File(AutoUpdate.updateConfigCache);
                dir2.mkdirs();
                File dir3 = new File(AutoUpdate.updateFilesCache);
                dir3.mkdirs();

                showUpdateState("create download buffer...", 5);
                showUpdateState("download update list...", 5);
                downloadTools.addItem(UpdateConfig.config.listUrl, AutoUpdate.updateCache + "/update.list");
                downloadTools.addItem(UpdateConfig.config.updateInfoUrl, AutoUpdate.updateCache + "/updatelog.txt");
                downloadTools.downLoadByList();
                downloadTools.resetList();
                showUpdateState("ready...", 5);
                String[] teams = jAppHelper.jDataRWHelper.readAllLines(AutoUpdate.updateCache + "/update.list");
                for (String url : teams) {
                    AutoUpdate.updateRemoteList.add(url);
                }

                //下载更新配置文件
                int uindex = 0;
                int needdownloadcount = 0;
                downloadTools.resetList();
                for (Iterator<String> it = AutoUpdate.updateRemoteList.iterator(); it.hasNext();) {
                    String urls = it.next();
                    uindex++;
                    String locals = AutoUpdate.updateConfigCache + "/update-" + uindex + ".cfg";
                    downloadTools.addItem(urls, locals);
                    AutoUpdate.updateLocalList.add(locals);
                }
                downloadTools.downLoadByList();
                downloadTools.resetList();
                for(String loca:updateLocalList)
                {
                    UpdateList ull = new UpdateList();
                    ull.loadList(loca);
                    if (ull.versionIndex > UpdateConfig.config.currentVersion)
                    {
                        if (ull.versionIndex > maxUpdateVersion)
                        {
                            maxUpdateVersion = ull.versionIndex;
                        }
                        needdownloadcount++;
                        AutoUpdate.needDownloadFileCount += ull.files.size();
                    }
                }
                
                if (!AutoUpdate.languageName.equals("zh-cn"))
                {
                   this.lblUpdateInfo.setText("Need to download the update package on " + needdownloadcount); 
                }else
                {
                   this.lblUpdateInfo.setText("目前有" + needdownloadcount + "个更新需要安装！");
                }
                waitForm.setVisible(false);

                String[] read = jAppHelper.jDataRWHelper.readAllLines(AutoUpdate.updateCache + "/updatelog.txt");
                String readme = "";
                for (String s : read) {
                    readme += s + "\n";
                }
                this.jtaUpdateLog.setText(readme);
                if (needdownloadcount > 0) 
                {
                    btnUpdate.setEnabled(true);
                }                
                btnStart.setEnabled(true);
                
                if (needdownloadcount <= 0)
                {
                    //无更新处理
                    onnoupdate();
                }
                
                showVersionState();

            } catch (Exception ex) {
                ex.printStackTrace();
                waitForm.setVisible(false);
                if (!AutoUpdate.languageName.equals("zh-cn"))
                {
                    javax.swing.JOptionPane.showMessageDialog(null, "Updates failed to initialize! May be the profile error or network connection exception！");
                }else
                {
                    javax.swing.JOptionPane.showMessageDialog(null, "更新程序初始化失败！可能是配置文件错误或网络连接异常！");
                }
                this.onnoupdate();
            }

        } else 
        {
            if (!AutoUpdate.languageName.equals("zh-cn"))
            {
               javax.swing.JOptionPane.showMessageDialog(null, "Read Config Error！");
            }else
            {
               javax.swing.JOptionPane.showMessageDialog(null, "配置文件载入失败！");
            }
            //jAppHelper.jCmdRunHelper.runSysCmd(UpdateConfig.config.localAppPath,false);
            System.exit(0);
        }
    }

    /**
     * 显示版本信息
     */
    private void showVersionState() 
    {
        if (!AutoUpdate.languageName.equals("zh-cn")) 
        {
            this.lblVersionState.setText("Local Update Version：" + UpdateConfig.config.currentVersion + " Remote Update Version：" + this.maxUpdateVersion); 
        } else
        {
            this.lblVersionState.setText("本地更新序号：" + UpdateConfig.config.currentVersion + " 远程服务器更新序号：" + this.maxUpdateVersion); 
        }
    }
    
    /**
     * 没有更新处理
     */
    private void onnoupdate() 
    {        
        try 
        {            
            // TODO add your handling code here:
            jAppHelper.jCmdRunHelper.runSysCmd(UpdateConfig.config.localAppPath,false);
            System.exit(0);
        } catch (Exception ex) 
        {
            if (!AutoUpdate.languageName.equals("zh-cn"))
            {
               javax.swing.JOptionPane.showMessageDialog(null, "Application Start Error！"); 
            }else
            {
               javax.swing.JOptionPane.showMessageDialog(null, "程序启动错误，可能是配置文件不正确！");        
            }
        }
    }
    
    /**
     * 显示更新日志
     * @param line
     * @param maxline 
     */
    public void showUpdateState(String line,int maxline)
    {
//        if (updatelogs.size() > maxline)
//        {
//            updatelogs.clear();
//        }
//        updatelogs.add(line);
//        String cnts = "";
//        for(int k = updatelogs.size() - 1;k >= 0;k--)
//        {
//            String s = updatelogs.get(k);
//            cnts += s + "\n";
//        }
//        this.jtaUpdateState.setText(cnts);
    }
    
    /**
     * 设置当前更新号
     */
    public void setShowUpdateNum(String updatenum)
    {
        this.lblUpdateNum.setText(updatenum);
    }
    
    /**
     * 设置当前更新文件
     */
    public void setShowUpdateFile(String updatefile)
    {
        this.lblUpdateFile.setText(updatefile);
    }
    
    /**
     * 设置当前下载大小
     */
    public void setShowDownloadSize(long datasize)
    {
        this.lblDownloadSize.setText((datasize / 1024) + " K"); 
    }
    
    /**
     * 设置当前文件数
     */
    public void setShowMaxFileCount(int filecount)
    {
       this.downProgress.setMaximum(AutoUpdate.needDownloadFileCount); 
    }
    
    /**
     * 设置当前文件号
     */
    public void setShowCurrentFileIndex(int fileindex)
    {
       currentDownloadFileIndex++;
       this.downProgress.setValue(currentDownloadFileIndex); 
    }
    
    /**
     * 设置状态文本
     * @param current
     * @param total 
     */
    public void setDownloadProgressText(int current,int total)
    {
        this.lblDownProgressText.setText((currentDownloadFileIndex + 1) + "/" + AutoUpdate.needDownloadFileCount);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt002 = new javax.swing.JLabel();
        lblHomePage = new javax.swing.JLabel();
        txt001 = new javax.swing.JLabel();
        lblManagerInfo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtaUpdateLog = new javax.swing.JTextArea();
        btnStart = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();
        lblUpdateInfo = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        downProgress = new javax.swing.JProgressBar();
        lblDownProgressText = new javax.swing.JLabel();
        txt107 = new javax.swing.JLabel();
        txt003 = new javax.swing.JLabel();
        lblUpdateNum = new javax.swing.JLabel();
        txt004 = new javax.swing.JLabel();
        lblDownloadSize = new javax.swing.JLabel();
        txt005 = new javax.swing.JLabel();
        lblUpdateFile = new javax.swing.JLabel();
        txt106 = new javax.swing.JLabel();
        lblVersionState = new javax.swing.JLabel();
        lblUpdateState = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        txt002.setText("维护者：");

        lblHomePage.setText("none");

        txt001.setText("官   网：");

        lblManagerInfo.setText("none");

        jtaUpdateLog.setColumns(20);
        jtaUpdateLog.setRows(5);
        jScrollPane1.setViewportView(jtaUpdateLog);

        btnStart.setText("启动");
        btnStart.setEnabled(false);
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnClose.setText("关闭");
        btnClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseActionPerformed(evt);
            }
        });

        lblUpdateInfo.setText("正在检查更新......");

        btnUpdate.setText("更新");
        btnUpdate.setEnabled(false);
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        lblDownProgressText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblDownProgressText.setText("0/0");

        txt107.setText("当前进度");

        txt003.setText("更新序号：");

        lblUpdateNum.setText("0");

        txt004.setText("已下载：");

        lblDownloadSize.setText("0");

        txt005.setText("文件名称：");

        lblUpdateFile.setText("none");

        txt106.setText("进度：");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt107, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt003)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblUpdateNum, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt106)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDownProgressText, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt004)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDownloadSize, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt005)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblUpdateFile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(downProgress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(downProgress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt107)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt003)
                        .addComponent(lblUpdateNum)
                        .addComponent(txt004)
                        .addComponent(lblDownloadSize)
                        .addComponent(txt005)
                        .addComponent(lblUpdateFile)
                        .addComponent(txt106)
                        .addComponent(lblDownProgressText)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblVersionState.setText("none");

        lblUpdateState.setText("none");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(lblVersionState, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt001)
                                        .addComponent(txt002))
                                    .addGap(33, 33, 33)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(lblHomePage, javax.swing.GroupLayout.DEFAULT_SIZE, 472, Short.MAX_VALUE)
                                        .addComponent(lblManagerInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addComponent(lblUpdateInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 565, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 751, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblUpdateState, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHomePage)
                    .addComponent(txt001))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt002)
                    .addComponent(lblManagerInfo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblVersionState, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblUpdateInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblUpdateState))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btnCloseActionPerformed

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
       this.onnoupdate();
    }//GEN-LAST:event_btnStartActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
        this.btnUpdate.setEnabled(false);
        this.btnStart.setEnabled(false);
        Thread t = new Thread(this);
        t.setDaemon(true);
        t.start();
    }//GEN-LAST:event_btnUpdateActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws Exception {
        try {
            /*
             * Set the Nimbus look and feel
             */
            //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            /*
             * If Nimbus (introduced in Java SE 6) is not available, stay with the
             * default look and feel. For details see
             * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
             */
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException ex) {
                java.util.logging.Logger.getLogger(AutoUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                java.util.logging.Logger.getLogger(AutoUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                java.util.logging.Logger.getLogger(AutoUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(AutoUpdate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            //</editor-fold>
            
            if (args != null && args.length >= 2)
            {
                UpdateConfig.configPath += args[0];
                AutoUpdate.languageName = args[1];
            }else
            {
                UpdateConfig.configPath += "gameupdate.cfg";
                AutoUpdate.languageName = "zh-cn";
            }
            UpdateConfig.config.loadConfig();
            
            AutoUpdate.waitForm = new WaitUpdate();
            //AutoUpdate.waitForm.setUndecorated(true);
            double xv = (AutoUpdate.waitForm.getToolkit().getScreenSize().getWidth() - AutoUpdate.waitForm.getWidth()) / 2;
            double yv = (AutoUpdate.waitForm.getToolkit().getScreenSize().getHeight() - AutoUpdate.waitForm.getHeight()) / 2;
            AutoUpdate.waitForm.setLocation((int)xv, (int)yv);
            AutoUpdate.waitForm.setVisible(true);
            AutoUpdate.waitForm.setLocation((int)xv, (int)yv);
            Thread.sleep(1000);
            /*
             * Create and display the form
             */
            java.awt.EventQueue.invokeLater(new Runnable() {

                public void run() 
                {                
                    try {
                        new AutoUpdate().setVisible(true);
                    } catch (Exception ex) {
                        Logger.getLogger(AutoUpdate.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        } catch (InterruptedException ex) {
            Logger.getLogger(AutoUpdate.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JProgressBar downProgress;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jtaUpdateLog;
    private javax.swing.JLabel lblDownProgressText;
    private javax.swing.JLabel lblDownloadSize;
    private javax.swing.JLabel lblHomePage;
    private javax.swing.JLabel lblManagerInfo;
    private javax.swing.JLabel lblUpdateFile;
    private javax.swing.JLabel lblUpdateInfo;
    private javax.swing.JLabel lblUpdateNum;
    private javax.swing.JLabel lblUpdateState;
    private javax.swing.JLabel lblVersionState;
    private javax.swing.JLabel txt001;
    private javax.swing.JLabel txt002;
    private javax.swing.JLabel txt003;
    private javax.swing.JLabel txt004;
    private javax.swing.JLabel txt005;
    private javax.swing.JLabel txt106;
    private javax.swing.JLabel txt107;
    // End of variables declaration//GEN-END:variables

    /**
     * 窗体线程
     */
    @Override
    public void run() 
    {
        downloadTools.form = this;
        Boolean haveerror = false;
        
        for (String localcfg : AutoUpdate.updateLocalList) {
            try {
                downloadTools.resetList();
                UpdateList ul = new UpdateList();
                ul.loadList(localcfg);
                if (ul.versionIndex > UpdateConfig.config.currentVersion) {
                    //showUpdateState("正在下载序号为 " + ul.versionIndex + " 的更新", 1000);
                    this.setShowUpdateNum(ul.versionIndex + "");
                    
                    if (!AutoUpdate.languageName.equals("zh-cn"))
                    {
                        this.lblUpdateState.setText("downloading");
                    }else
                    {
                        this.lblUpdateState.setText("正在下载");
                    }
                    
                    for (Object obj : ul.files)
                    {
                        FileEntry fe = (FileEntry)obj;
                        String key = fe.Remote;
                        String value = fe.local;
                        downloadTools.addItem(key, value);
                    }
                    downloadTools.downLoadByList();
                    showUpdateState("Index:" + ul.versionIndex + " Finish", 1000);
                    
                    if (!AutoUpdate.languageName.equals("zh-cn"))
                    {
                        this.lblUpdateState.setText("installing");
                    }else
                    {
                        this.lblUpdateState.setText("正在安装");
                    }
                    
                    showUpdateState("Installing", 1000);
                    File script = new File(ul.finishScriptPath);
                    if (script.exists()) {
                        ArrayList<String> scripts = new ArrayList<String>();
                        scripts.add("cd " + script.getParent());
                        scripts.add("chmod +x " + script.getName());
                        scripts.add("./" + script.getName());
                        jAppHelper.jDataRWHelper.writeAllLines(jAppHelper.jCmdRunHelper.getCmdRunScriptBufferDir() + "/gameupdate.sh", jAppHelper.jDataRWHelper.convertTo(scripts.toArray()));

                        jAppHelper.jCmdRunHelper.runSysCmd("chmod +x " + jAppHelper.jCmdRunHelper.getCmdRunScriptBufferDir() + "/gameupdate.sh", true);
                        jAppHelper.jCmdRunHelper.runSysCmd(jAppHelper.jCmdRunHelper.getCmdRunScriptBufferDir() + "/gameupdate.sh", true);
                    }
                    showUpdateState("Install Finish", 1000);
                    
                    if (!AutoUpdate.languageName.equals("zh-cn"))
                    {
                        this.lblUpdateState.setText("finish");
                    }else
                    {
                        this.lblUpdateState.setText("安装完成");
                    }
                    
                    UpdateConfig.config.currentVersion = ul.versionIndex;
                    UpdateConfig.config.saveConfig(UpdateConfig.configPath);
                } else {
                    showUpdateState("Index:" + ul.versionIndex + " Installed", 1000);
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                haveerror = true;
                
                if (!AutoUpdate.languageName.equals("zh-cn"))
                {
                    this.lblUpdateState.setText("error");
                }else
                {
                    this.lblUpdateState.setText("出错");
                }

                showUpdateState(ex.toString(), 1000);
                break;

            }
        }
        if (haveerror) {
            try {
                if (!AutoUpdate.languageName.equals("zh-cn"))
                {
                   javax.swing.JOptionPane.showMessageDialog(null, "Update Error！"); 
                }else
                {
                   javax.swing.JOptionPane.showMessageDialog(null, "对不起，更新出错，请联系维护者！");
                }
                jAppHelper.jDataRWHelper.writeAllLines(jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/autoupdate.log", jAppHelper.jDataRWHelper.convertTo(updatelogs.toArray()));
                System.exit(0);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            downloadTools.form = null;
            btnStart.setEnabled(true);
            if (!AutoUpdate.languageName.equals("zh-cn"))
            {
               lblUpdateInfo.setText("finish!"); 
            }else
            {
               lblUpdateInfo.setText("更新完成，可以启动了！");
            }
        }

    }

    private void loadLanguage()
    {
        if (!AutoUpdate.languageName.equals("zh-cn"))
        {
            this.txt001.setText("Homepage:");
            this.txt002.setText("Maintainers:");
            this.txt003.setText("Version:");
            this.txt004.setText("Size:");
            this.txt005.setText("File:");
            this.txt106.setText("Progress:");
            this.lblUpdateInfo.setText("Checking for updates ...");
            this.btnUpdate.setText("Update");
            this.btnStart.setText("Run");
            this.btnClose.setText("Close");
            this.txt107.setText("Current");
        }
    }

}
