/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gameautoupdate;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

/**
 *
 * @author wcss
 */
public class UpdateList 
{
   public int versionIndex = 0;
   public ArrayList files = new ArrayList();
   public String updateLogUrl = "";
   public String finishScriptPath = "";
   public static UpdateList list = new UpdateList();
      
   /**
    * 载入内容
    * @param loadpath
    * @throws Exception 
    */
   public void loadList(String loadpath) throws Exception
   {
       File f = new File(loadpath);
       if (f.exists())
       {
           String[] texts = jAppHelper.jDataRWHelper.readAllLines(loadpath);           
           loadBaseInfo(new String[] { texts[0],texts[1] ,texts[2],texts[3] });
           ArrayList filess = new ArrayList();
           for(String ss : texts)
           {
              filess.add(ss);   
           }          
           filess.remove(0);
           filess.remove(0);
           filess.remove(0);
           filess.remove(0);           
           loadFiles(jAppHelper.jDataRWHelper.convertTo(filess.toArray()));
       }else
       {
           throw new Exception("更新列表文件没有找到!");
       }
   }
   
   /*
    * 载入基础信息
    */
   private void loadBaseInfo(String[] team)
   {
       for(String s:team)
       {
           String str = s.trim();
           if (str.startsWith("versionindex="))
           {
               versionIndex = Integer.parseInt(str.replace("versionindex=", ""));
           }else if (str.startsWith("updatelogurl="))
           {
               updateLogUrl = str.replace("updatelogurl=", "");
           }else if (str.startsWith("finishscriptpath="))
           {
               finishScriptPath = str.replace("finishscriptpath=", "");
           }
       }
   }
   
   /**
    * 载入文件列表
    * @param team 
    */
   private void loadFiles(String[] team)
   {
       for(String s:team)
       {
           String str = s.trim();
           if (str.contains(","))
           {
               //符合条件的地址段
               String[] cnt = str.split(",");
               this.files.add(new FileEntry(cnt[0], cnt[1]));
           }
       } 
   }
   
   /**
    * 保存列表
    * @param savepath 
    */
   public void saveList(String savepath) throws Exception
   {
      ArrayList al = new ArrayList();
      al.add("[[Base]]");
      al.add("versionindex=" + this.versionIndex);
      al.add("updatelogurl=" + this.updateLogUrl);
      al.add("finishscriptpath=" + this.finishScriptPath);
      al.add("[[Files]]");
      for(Object obj : files)
      {  
         FileEntry fe = (FileEntry)obj;
         String key=fe.Remote;  
         String value=fe.local;  
         al.add(key + "," + value);  
      }
      jAppHelper.jDataRWHelper.writeAllLines(savepath, jAppHelper.jDataRWHelper.convertTo(al.toArray()));
   }
   
}
