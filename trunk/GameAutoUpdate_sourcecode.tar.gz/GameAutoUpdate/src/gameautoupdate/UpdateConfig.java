/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gameautoupdate;

import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author wcss
 */
public class UpdateConfig 
{
   public String listUrl = "";
   public int currentVersion = 0;
   public String softName = "";
   public String homePage = "";
   public String managerInfo = "";
   public String updateInfoUrl = "";
   public String localAppPath = "";
   public static String configPath = "/etc/"; 
   public static UpdateConfig config = new UpdateConfig();
   
   /**
    * 读取配置文件
    * @throws Exception 
    */
   public void loadConfig() throws Exception
   {
       File f = new File(UpdateConfig.configPath);
       if (f.exists())
       {
          String[] lines = jAppHelper.jDataRWHelper.readAllLines(f.getAbsolutePath());
          for(String s:lines)
          {
             String str = s.trim();
             if (str.trim().startsWith("listurl="))
             {
                 listUrl = str.replace("listurl=", "");
             }else if (str.trim().startsWith("currentversion="))
             {
                 currentVersion = Integer.parseInt(str.replace("currentversion=", ""));
             }else if (str.trim().startsWith("softname="))
             {
                 softName = str.replace("softname=", "");
             }else if (str.trim().startsWith("homepage="))
             {
                 homePage = str.replace("homepage=", "");
             }else if (str.trim().startsWith("managerinfo="))
             {
                 managerInfo = str.replace("managerinfo=", "");
             }else if (str.trim().startsWith("updateinfourl="))
             {
                 updateInfoUrl = str.replace("updateinfourl=", "");
             }else if (str.trim().startsWith("localapppath="))
             {
                 localAppPath = str.replace("localapppath=", "");
             }
          }
          
       }else
       {
           throw new Exception("更新配置文件没有找到!");
       }
   }
   
   /**
    * 保存配置文件
    * @param path
    * @throws Exception 
    */
   public void saveConfig(String path) throws Exception
   {
       ArrayList<String> al = new ArrayList<String>();
       al.add("listurl=" + this.listUrl);
       al.add("currentversion=" + this.currentVersion);
       al.add("softname=" + this.softName);
       al.add("homepage=" + this.homePage);
       al.add("managerinfo=" + this.managerInfo);
       al.add("updateinfourl=" + this.updateInfoUrl);
       al.add("localapppath=" + this.localAppPath);
       jAppHelper.jDataRWHelper.writeAllLines(path, jAppHelper.jDataRWHelper.convertTo(al.toArray()));
   }
   
}
