/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gameautoupdate;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

/**
 *
 * @author wcss
 */
public class AuthenticatorImpl extends Authenticator 
{
    protected String user;
    protected String pass;

    public AuthenticatorImpl(String uid, String pwd) 
    {
        this.user = uid;
        this.pass = pwd;            
    }
    
    @Override
    protected PasswordAuthentication getPasswordAuthentication()
    {
        return new PasswordAuthentication(this.user,this.pass.toCharArray());
    }
}