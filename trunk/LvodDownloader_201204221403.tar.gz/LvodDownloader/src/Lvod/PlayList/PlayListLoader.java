/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lvod.PlayList;

import Lvod.Config.ConfigLoader;
import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author wcss
 */
public class PlayListLoader 
{
   public ArrayList<String> playList = new ArrayList<String>();
   public static PlayListLoader playlist = new PlayListLoader();
   
   /**
    * load playlist
    */
   public void loadPlayList() throws Exception
   {
      File configfile = new File(jAppHelper.jCmdRunHelper.getUserHomeDirPath() + "/" + ConfigLoader.config.playListName);
      if (configfile.exists())
      {
          playList.clear();
          String[] team = jAppHelper.jDataRWHelper.readAllLines(configfile.getAbsolutePath());
          for(String str:team)
          {
              playList.add(str.trim());
          }
      } 
   }
   
   /**
    * save playlist
    */
   public void savePlayList(String savepath) throws Exception
   {
     jAppHelper.jDataRWHelper.writeAllLines(savepath, jAppHelper.jDataRWHelper.convertTo(playList.toArray()));  
   }
}
