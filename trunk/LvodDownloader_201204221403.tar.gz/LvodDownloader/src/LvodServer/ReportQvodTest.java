/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package LvodServer;

/**
 *
 * @author wcss
 */
public class ReportQvodTest implements JReportQvodUrl {

    @Override
    public void reportQvodUrl(Object sender, String url) {
        System.out.println("Qvod地址：" + url + "\n");
    }
    
}
