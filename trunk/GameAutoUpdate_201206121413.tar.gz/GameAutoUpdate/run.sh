gksu "java -jar /home/wcss/NetBeansProjects/GameAutoUpdate/dist/GameAutoUpdate.jar lvoddownloader_update.cfg zh-cn"
