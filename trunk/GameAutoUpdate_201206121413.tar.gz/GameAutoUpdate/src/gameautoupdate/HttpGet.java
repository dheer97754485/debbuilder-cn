/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gameautoupdate;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * <p>Title: 个人开发的API</p> <p>Description: 将指定的HTTP网络资源在本地以文件形式存放</p>
 * <p>Copyright: Copyright (c) 2004</p> <p>Company: NewSky</p>
 *
 * @author MagicLiao
 * @version 1.0
 */
public class HttpGet {

    public final static boolean DEBUG = true;//调试用
    private static int BUFFER_SIZE = 8096;//缓冲区大小
    private Vector vDownLoad = new Vector();//URL列表
    private Vector vFileList = new Vector();//下载后的保存文件名列表
    public String currentUrl = "";
    public AutoUpdate form = null;
    public int maxLine = 1000;
    public ArrayList<String> finishList = new ArrayList<String>();
    private long allsize = 0;

    /**
     * 构造方法
     */
    public HttpGet() {
    }

    /**
     * 清除下载列表
     */
    public void resetList() {
        vDownLoad.clear();
        vFileList.clear();
        currentUrl = "";
        finishList.clear();
    }

    /**
     * 增加下载列表项
     *
     * @param url String
     * @param filename String
     */
    public void addItem(String url, String filename) {
        vDownLoad.add(url);
        vFileList.add(filename);
    }

    /**
     * 打印提示到界面
     *
     * @param line
     */
    public void printToForm(String line) {
        if (form != null) {
            form.showUpdateState(line, maxLine);
        }
    }

    /**
     * 根据列表下载资源
     */
    public void downLoadByList() throws Exception
    {
        String url = null;
        String filename = null;
        allsize = 0;
        if (this.form != null) {
            this.form.setShowMaxFileCount(vDownLoad.size());
            //this.form.setShowCurrentFileIndex(0);
        }
        //按列表顺序保存资源
        for (int k = 0; k < vDownLoad.size(); k++) 
        {
            url = (String) vDownLoad.get(k);
            filename = (String) vFileList.get(k);
            if (this.form != null)
            {
                this.form.setDownloadProgressText(k+1,vDownLoad.size());
            }
            try 
            {
                if (this.form != null) 
                {
                    System.out.println(filename);
                    this.form.setShowUpdateFile(new File(filename).getName());
                }

                saveToFile(url, filename);
            } catch (IOException err) 
            {
                if (DEBUG) {
                    printToForm("[" + url + "] download error!!!");
                    System.out.println("[" + url + "] download error!!!");
                    throw new Exception("[" + url + "] download error!!!");
                }
            }

            if (this.form != null) {
                this.form.setShowCurrentFileIndex(k + 1);
            }

        }
        if (DEBUG) {
            //printToForm("下载完成!!!");
            System.out.println("download finsih!!!");
        }
    }

    /**
     * 将HTTP资源另存为文件
     *
     * @param destUrl String
     * @param fileName String
     * @throws Exception
     */
    public void saveToFile(String destUrl, String fileName) throws IOException {
        this.currentUrl = destUrl;
        FileOutputStream fos = null;
        BufferedInputStream bis = null;
        HttpURLConnection httpUrl = null;
        URL url = null;
        byte[] buf = new byte[BUFFER_SIZE];
        int size = 0;

        //建立链接
        url = new URL(destUrl);
        httpUrl = (HttpURLConnection) url.openConnection();
        //连接指定的资源
        httpUrl.connect();
        //获取网络输入流
        bis = new BufferedInputStream(httpUrl.getInputStream());
        //创建路径
        File f = new File(fileName);
        if (f.exists()) {
            f.delete();
        }
        File dir = new File(f.getParent());
        dir.mkdirs();
        //建立文件
        fos = new FileOutputStream(fileName);
        if (this.DEBUG) {
            //printToForm("正在获取链接[" + destUrl + "]的内容...将其保存为文件[" + fileName + "]");
            System.out.println("[" + destUrl + "] downloading... save to [" + fileName + "]");
        }

        long filelength = 0;
        //保存文件
        while ((size = bis.read(buf)) != -1) {
            fos.write(buf, 0, size);
            if (this.DEBUG) {
                filelength += size;

                allsize += size;

                if (this.form != null) {
                    this.form.setShowDownloadSize(allsize);
                }
                //printToForm("(" + fileName + ":" + filelength + ")");
                System.out.println("(" + fileName + ":" + filelength + ")");

            }
        }

        fos.close();
        bis.close();
        httpUrl.disconnect();

        if (finishList.contains(this.currentUrl)) {
            //重复下载
        } else {
            finishList.add(this.currentUrl);
        }
    }

    /**
     * 设置代理服务器
     *
     * @param proxy String
     * @param proxyPort String
     */
    public void setProxyServer(String proxy, String proxyPort) {
        //设置代理服务器
        System.getProperties().put("proxySet", "true");
        System.getProperties().put("proxyHost", proxy);
        System.getProperties().put("proxyPort", proxyPort);
    }

    /**
     * 设置认证用户名与密码
     *
     * @param uid String
     * @param pwd String
     */
    public void setAuthenticator(String uid, String pwd) {
        Authenticator.setDefault(new AuthenticatorImpl(uid, pwd));
    }
//    /**
//     * 主方法(用于测试)
//     *
//     * @param argv String[]
//     */
//    public static void main(String argv[]) {
//        HttpGet oInstance = new HttpGet();
//        try {
////增加下载列表（此处用户可以写入自己代码来增加下载列表）
//            oInstance.addItem("http://www.ebook.com/java/网络编程001.zip", "./网络编程1.zip");
//            oInstance.addItem("http://www.ebook.com/java/网络编程002.zip", "./网络编程2.zip");
//            oInstance.addItem("http://www.ebook.com/java/网络编程003.zip", "./网络编程3.zip");
//            oInstance.addItem("http://www.ebook.com/java/网络编程004.zip", "./网络编程4.zip");
//            oInstance.addItem("http://www.ebook.com/java/网络编程005.zip", "./网络编程5.zip");
//            oInstance.addItem("http://www.ebook.com/java/网络编程006.zip", "./网络编程6.zip");
//            oInstance.addItem("http://www.ebook.com/java/网络编程007.zip", "./网络编程7.zip");
////开始下载
//            oInstance.downLoadByList();
//        } catch (Exception err) {
//            System.out.println(err.getMessage());
//        }
//    }
}
