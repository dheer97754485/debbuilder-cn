/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gameautoupdate;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wcss
 */
public class GameAutoUpdate {

    /**
     * @param args the command line arguments
     */
    public static void testmethod(String[] args)
    {
        try {
            //            UpdateConfig.config.saveConfig("/home/wcss/test.config");
            HttpGet hg = new HttpGet();
            hg.addItem("http://192.168.0.154/update.list", "/home/wcss/fff.list");
            hg.downLoadByList();
            //hg.addItem(null, null);
    //        UpdateConfig.config.listUrl = "http://aaa.com/aa.cfg";
    //        UpdateConfig.config.currentVersion = 1;
    //        UpdateConfig.config.softName = "时空浩劫";
    //        UpdateConfig.config.homePage = "http://www.baidu.com";
    //        UpdateConfig.config.managerInfo = "五彩书生（wcss2010@qq.com）";
    //        UpdateConfig.config.updateInfoUrl = "http://aaa.com/update.txt";
    //        UpdateConfig.config.localAppPath = "/opt/gamesss/gamestart.sh";
            try {
    //            UpdateConfig.config.saveConfig("/home/wcss/test.config");
                
                UpdateConfig.configPath = "/home/wcss/test.config";
                UpdateConfig.config.loadConfig();
                System.out.println("url:" + UpdateConfig.config.listUrl);
                System.out.println("version:" + UpdateConfig.config.currentVersion);
                System.out.println("soft:" + UpdateConfig.config.softName);
                System.out.println("home:" + UpdateConfig.config.homePage);
                System.out.println("info:" + UpdateConfig.config.managerInfo);
                System.out.println("update:" + UpdateConfig.config.updateInfoUrl);
                System.out.println("local:" + UpdateConfig.config.mainAppName);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            
//            UpdateList.list.versionIndex = 3;
//            UpdateList.list.updateLogUrl = "http://风址/log.txt";
//            UpdateList.list.finishScriptPath = "/opt/app/exe.sh";
//            UpdateList.list.files.put("http://a.com/a.zip", "/opt/a/a.zip");
//            UpdateList.list.files.put("http://a.com/b.zip", "/opt/a/b.zip");
//            UpdateList.list.files.put("http://a.com/c.zip", "/opt/a/c.zip");
//            UpdateList.list.saveList("/home/wcss/update.list");
            
              UpdateList.list.loadList("/home/wcss/update.list");
              
              System.out.println("versionss:" + UpdateList.list.versionIndex);
              System.out.println("log:" + UpdateList.list.updateLogUrl);
              System.out.println("script:" + UpdateList.list.finishScriptPath);
              System.out.println("files:" + UpdateList.list.files.size());
              
        } catch (Exception ex) {
            ex.printStackTrace();
        }       
        
    }
}
