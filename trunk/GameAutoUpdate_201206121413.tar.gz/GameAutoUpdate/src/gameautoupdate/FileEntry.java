/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gameautoupdate;

/**
 *
 * @author wcss
 */
public class FileEntry
{
    public FileEntry(String url,String file)
    {
        this.Remote = url;
        this.local = file;
    }
    
    public String Remote;
    public String local;
}
